package com.rdb.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/UserEdit")
public class UserEdit extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tiffin_service_db","root","ucs22m1018");
			if(con!=null) {
				HttpSession session=request.getSession();
				String email=session.getAttribute("email").toString();
				String name=request.getParameter("name");
				String phone_no=request.getParameter("phone_no");
				String college=request.getParameter("college");
				String gender=request.getParameter("gender");
				String address=request.getParameter("address");
				PreparedStatement ps=con.prepareStatement("UPDATE user SET name=?, phone_no=?, college=?, gender=?, address=? WHERE email=?");
				ps.setString(1, name);
				ps.setString(2, phone_no);
				ps.setString(3, college);
				ps.setString(4, gender);
				ps.setString(5, address);
				ps.setString(6, email);
				int res=ps.executeUpdate();
				if(res>0) {
					session.setAttribute("name", name);
					session.setAttribute("phone_no", phone_no);
					session.setAttribute("college", college);
					session.setAttribute("gender", gender);
					session.setAttribute("address", address);
				}
				RequestDispatcher rd=request.getRequestDispatcher("user_dashboard.jsp");
				rd.include(request, response);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
